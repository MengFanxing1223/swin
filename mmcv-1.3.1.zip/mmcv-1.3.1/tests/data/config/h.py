item1 = '{{fileBasename}}'
item2 = '{{ fileDirname}}'
item3 = 'abc_{{ fileBasenameNoExtension }}'
