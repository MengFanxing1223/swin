item1 = [1, 2]
item2 = {'a': 0}
item3 = True
item4 = 'test'
